#!/bin/bash

sudo apt-get install algobox -y


